let errorParagraph = document.getElementById("error")

function purchase() {
    console.log("button clicked")
    errorParagraph.textContent = "Something went wrong, please try again"   
}